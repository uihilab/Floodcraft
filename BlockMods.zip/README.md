# FloodCraft - Flood Mitigation Strategy Game

<div style="text-align: center;">
    <img src="https://github.com/uihilab/floodcraft/blob/main/floodcraft_gameplay.png" alt="FloodCraft Gameplay" style="width:60%;">
</div>

## About
Welcome to FloodCraft, an innovative and engaging educational game designed to teach K-12 students about essential flood mitigation and emergency response strategies in an interactive and enjoyable manner. Built on the popular Minecraft platform (Java Edition 1.21.4 with Fabric), this game provides a unique opportunity for players to explore various flood preparedness techniques in St. Bernard Parish, Louisiana. Players can interact with AI-powered NPC guides to learn about flooding history and strategies, empowering them with knowledge that can make a difference in their real-world communities.

The game features five distinct challenge levels, each representing a critical aspect of flood mitigation, community planning, or emergency response. From deploying sandbag perimeters and clearing street drains to securing household assets, operating reservoir spillways, and conducting swamp rescues, players will embark on a learning adventure that demonstrates how preparedness enhances community resilience to flooding.

## How to Play

If you would like to play the game, please follow the setup instructions below.

### How to Install

**Prerequisites:** 
- Java Development Kit (JDK) 21 (required for Minecraft 1.21.4)
- Minecraft Java Edition (Version 1.21.4)
- Fabric Loader (Version 0.19.3 or latest for 1.21.4)

You can find tutorials online for installing Minecraft Java Edition, Fabric, and Java 21 on your specific operating system.

#### Installation of Fabric and Required Mods

1. Install **Fabric Loader** for Minecraft 1.21.4 using the installer from the [Fabric website](https://fabricmc.net/).
2. Locate the `minecraft` folder on your computer (or your launcher instance's directory), then navigate to the `mods` folder inside it.
3. Place the following **required** mods (compatible with Minecraft 1.21.4) into the `mods` folder:
   - **Fabric API** (Download from CurseForge or Modrinth)
   - **CreatureChat** (Provides the AI-powered NPC interactions, compatible with 1.21.4)
   - **Easy NPC** and **Easy NPC Config UI** (Handles custom guide NPCs, compatible with 1.21.4)

*(Note: Optional builder tools like **Big Sign Writer**, **Axiom**, and **WorldEdit** are only used for building/configuration and are not required for players to play the game.)*

#### Download the World Folder

1. Locate the world folder `Arnis World 4.2_backup_level4_start` in this repository, or download and extract the `Floodcraft St Bernard Parish.zip` archive.
2. Place the world folder inside the `saves` folder located in your `minecraft` directory.
3. When you open the game, you will see the world in your Singleplayer world list. Select the world and start playing!

### Tasks

There are five tasks that players can choose to complete, each representing a different challenge:

1. **Sandbag Defense:** Learn how sandbags are used as a temporary barrier against rising water. Observe the floodwaters rise and verify that the sandbag perimeter successfully protects the house.
   
2. **Wildlife Rescue:** Help! Floodwaters are rising in the Jean Lafitte swamp. Locate and rescue two stranded pets: Whiskers (a Siamese cat) and Buddy (a dog). Leash them and guide them across the bridge to the safety pen before the timer runs out.

3. **Storm Drains:** Leaves and trash are clogging the neighborhood storm drains, causing the streets to flood. Locate and clear all 5 clogged drains (marked with glowing outlines) using your shears to drain the water from the streets.

4. **Save the Furniture:** Move valuable furniture and items to safety upstairs. Collect 12 items (beds, bookshelves, jukebox, furnace, crafting table, lectern, and armor stand with diamond armor) using your pickaxe and place them in the upstairs chest before the house floods.

5. **Spillway Repair:** Repair a reservoir spillway to safely release high water. Swim down to clear 3 blockages from the spillway gate, retrieve the red cogwheel from the toolbox to place it on the control panel, flip the generator switch, and pull the main lever to open the gates and save the town!

## Feedback

We welcome your feedback! Please report any issues or suggestions by filing an [issue](https://github.com/uihilab/floodcraft/issues) on our GitHub page.

## License

This project is licensed under the MIT License. See the [LICENSE](https://github.com/uihilab/floodcraft/blob/master/LICENSE) file for details.

## Acknowledgements

FloodCraft was developed by the University of Iowa Hydroinformatics Lab (UIHI Lab). Visit us at [hydroinformatics.uiowa.edu](https://hydroinformatics.uiowa.edu/).

## References

Emiroglu, E., Grant, C. A., Sermet, Y., & Demir, I. (2024). Floodcraft: Game-based Interactive Learning Environment using Minecraft for Flood Mitigation and Preparedness for K-12 Education. EarthArxiv, 7815. [https://doi.org/10.31223/X52Q55](https://doi.org/10.31223/X52Q55)
